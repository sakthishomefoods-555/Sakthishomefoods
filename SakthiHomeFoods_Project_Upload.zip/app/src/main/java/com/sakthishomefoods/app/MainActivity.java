package com.sakthishomefoods.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebResourceRequest;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final String PRODUCT_API_URL = "https://script.google.com/macros/s/AKfycbzSkEkGPV3eRIw2BrBWUjTPS31Ihkd0sIhVzq0yY3At3jWbRXnt0_1-A8ERGt0VLTW0og/exec";
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                String u=req.getUrl().toString();
                if (u.startsWith("https://wa.me/") || u.startsWith("whatsapp://")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); } catch(Exception e) {}
                    return true;
                }
                return false;
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                fetchProductCatalog();
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void fetchProductCatalog() {
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(PRODUCT_API_URL);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(12000);
                conn.setReadTimeout(12000);
                conn.setInstanceFollowRedirects(true);
                conn.setRequestProperty("Accept", "application/json");
                int code = conn.getResponseCode();
                InputStream stream = code >= 200 && code < 400 ? conn.getInputStream() : conn.getErrorStream();
                if (stream == null) throw new Exception("HTTP " + code);
                StringBuilder out = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = br.readLine()) != null) out.append(line);
                }
                final String json = out.toString();
                if (code < 200 || code >= 400 || !json.trim().startsWith("[")) throw new Exception("Invalid API response");
                runOnUiThread(() -> {
                    String js = "if(window.setRemoteProducts){window.setRemoteProducts(" + json + ");}";
                    webView.evaluateJavascript(js, null);
                });
            } catch (Exception ignored) {
                // The app keeps its bundled catalogue for offline use.
            } finally {
                if (conn != null) conn.disconnect();
            }
        }).start();
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
