SAKTHI'S HOME FOODS — CHROME + OFFLINE APP

1) Quick use:
   Open index.html directly in Chrome. Product browsing and the cart work offline because the app uses localStorage.

2) Installable PWA / full offline cache:
   Chrome only allows a service worker on HTTPS or localhost.
   From this folder, run a local server:
      python -m http.server 8080
   Then open:
      http://localhost:8080
   In Chrome, choose "Install app" / "Add to Home screen".
   After the first load, the app shell is cached for offline use.

3) WhatsApp:
   The cart has an "Order on WhatsApp" button. It opens WhatsApp with the order text.
   Replace the wa.me link in index.html with the business WhatsApp number when you are ready.

4) Product prices and names are sample/current app content and can be edited in the PRODUCTS array near the top of index.html.
