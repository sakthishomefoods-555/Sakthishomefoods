SAKTHI'S HOME FOODS — INSTALLABLE CHROME + OFFLINE PWA

IMPORTANT:
A full installable PWA cannot be installed from a content:// or file:// URL.
It must be opened from HTTPS (recommended) or localhost.

FILES:
- index.html — app
- manifest.webmanifest — Android/Chrome app information
- sw.js — offline cache
- icon-192.png / icon-512.png — app icons

ANDROID INSTALL:
1. Put this folder on an HTTPS website (for example, your own website/hosting).
2. Open the HTTPS app address in Chrome on Android.
3. Tap ⋮ (three dots).
4. Tap "Install app" if shown.
   If Chrome shows "Add to Home screen", use that option.
5. Confirm the name "SAKTHI'S HOME FOODS".
6. The app icon will appear on the Android home screen/app launcher.
7. Open it from the new icon. It will run as a standalone app.

OFFLINE:
Open the app once while online and allow the page to finish loading.
The service worker then caches the app shell. Product browsing and the cart use localStorage.

WHATSAPP:
The order button is already configured for:
+91 99449 11196

PRODUCTS UPDATED:
- Moringa Soup Mix: 100g ₹99, 250g ₹229
- Kollu Soup Mix: 100g ₹99, 250g ₹229
- Pirandai Soup Mix: 100g ₹99, 250g ₹229
- Karuvepilai Podi: 100g ₹99, 250g ₹239
- Poondu Podi: 100g ₹199, 250g ₹399
- Puliyotharai Thokku: 200g ₹399
- Poondu Thokku: 200g ₹399
- Pirandai Thokku: 200g ₹399
- Milagai Thool: 100g ₹129, 250g ₹289
- Kulambu Milagai Thool: 100g ₹149, 250g ₹269
- Health Mix (Millets Rich) Chocolate Flavour: 100g ₹99, 250g ₹199

The supplied Moringa, Kollu, Pirandai Thokku, Poondu Thokku and Puliyotharai Thokku artwork is included in the app as product images.


APP ICON UPDATED:
The SAKTHI'S HOME FOODS Golden Badge supplied by the user is now used for the PWA icons and favicon.


ADMIN PRODUCT EDITOR:
1. Open the installed app.
2. Tap ⚙ Admin.
3. Default Admin PIN: 1234.
4. Edit product photo, Tamil/English names, category, description, sizes and prices.
5. Use Save this product or Save All Changes.
6. Use Export Catalog to keep a backup.
7. Use Import Catalog to restore a backup on another device/browser.
Note: this is a local/offline editor; it does not provide server-side security or sync between devices.
